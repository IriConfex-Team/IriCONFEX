import { useState } from 'react';
import type { RespuestaSolicitud } from '../api/cliente';
import { copiarTexto } from './copiarTexto';

export function SolicitudEnviada({ respuesta }: { respuesta: RespuestaSolicitud }) {
  const [copiado, setCopiado] = useState<boolean | null>(null);

  async function copiar() {
    setCopiado(await copiarTexto(respuesta.mensaje));
  }

  return (
    <section aria-labelledby="titulo-enviada">
      <h2 id="titulo-enviada">¡Solicitud lista!</h2>
      <p>
        Tu referencia es <strong>{respuesta.referencia}</strong>. Envía este mensaje a la costurera
        para recibir tu cotización.
      </p>

      <pre style={{ whiteSpace: 'pre-wrap' }}>{respuesta.mensaje}</pre>

      <a href={respuesta.enlaceWhatsapp} target="_blank" rel="noopener noreferrer">
        Abrir WhatsApp
      </a>
      <button type="button" onClick={copiar}>
        Copiar mensaje
      </button>
      <p role="status">
        {copiado === true && 'Mensaje copiado'}
        {copiado === false && 'No se pudo copiar. Selecciona el texto y cópialo a mano.'}
      </p>
    </section>
  );
}
